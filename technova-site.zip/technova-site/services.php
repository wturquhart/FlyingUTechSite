<?php include 'includes/header.php'; ?>
<div class="hero-section">
    <h1>Our Services</h1>
    <p>We provide a range of services to help your business grow and thrive.</p>
</div>
<div class="content">
    <div class="service-card">
        <h2>Software Development</h2>
        <p>Custom software solutions tailored to your needs.</p>
    </div>
    <div class="service-card">
        <h2>Cybersecurity Solutions</h2>
        <p>Protecting your data and systems from cyber threats.
    </div>
    <div class="service-card">
        <h2>Digital Transformation</h2>
        <p>Redefining business processes with technology.</p>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
