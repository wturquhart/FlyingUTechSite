<header>
    <nav>
        <ul>
            <li><a href="#home" class="active">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </nav>
</header>

<?php
if (isset($_GET['section'])) {
    $section = $_GET['section'];
    include "$section.php";
} else {
    include 'home.php';
}
?>
