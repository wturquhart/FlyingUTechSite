<footer>
    <a href="#privacy" class="icon-link"><i class="fas fa-lock"></i></a>
    <a href="#terms" class="icon-link"><i class="fas fa-file-alt"></i></a>
    <a href="https://www.facebook.com/TechNova" target="_blank" class="icon-link"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.twitter.com/TechNova" target="_blank" class="icon-link"><i class="fab fa-twitter"></i></a>

    <button class="back-to-top">
        <i class="fas fa-arrow-up"></i>
    </button>
</footer>

<script src="js/scripts.js"></script>
