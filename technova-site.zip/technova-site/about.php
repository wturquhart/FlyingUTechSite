<?php include 'includes/header.php'; ?>
<div class="hero-section">
    <h1>About TechNova</h1>
    <p>TechNova is a leading tech company offering cutting-edge solutions in software development, cybersecurity, and digital transformation.</p>
</div>
<div class="content">
    <!-- Add more content here -->
</div>
<?php include 'includes/footer.php'; ?>
