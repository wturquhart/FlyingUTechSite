document.addEventListener("DOMContentLoaded", function() {
    const scrollIndicator = document.querySelector('.scroll-indicator');
    const backToTopButton = document.querySelector('.back-to-top');

    // Show/hide scroll indicator based on scroll position
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            scrollIndicator.style.opacity = 1;
            backToTopButton.style.opacity = 1;
        } else {
            scrollIndicator.style.opacity = 0;
            backToTopButton.style.opacity = 0;
        }
    });

    // Scroll to top functionality
    backToTopButton.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});
