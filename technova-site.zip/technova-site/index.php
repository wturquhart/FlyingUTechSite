<?php include 'includes/header.php'; ?>
<div class="hero-section" style="background-image: url('path_to_image.jpg');">
    <h1>Welcome to TechNova</h1>
    <p>We are dedicated to providing innovative solutions for your technology needs.</p>
    <a href="#" class="button">Get Started</a>
</div>
<div class="service-card-container" style="background-image: url('path_to_service_bg.jpg');">
    <!-- Add more service cards here -->
</div>
<div class="content">
    <!-- Add more content here -->
</div>
<?php include 'includes/footer.php'; ?>
